module.exports = {
	dist : [
		'concat', 'sass:dist'
	],
	dev : [
		'concat', 'sass:dev'
	]
};