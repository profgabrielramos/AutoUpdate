module.exports = {
	dist : {
		files : {
			'<%= concat.admin.dest %>' : '<%= concat.admin.dest %>',
			'<%= concat.front.dest %>' : '<%= concat.front.dest %>'
		}
	}
};