=== MOD Auto Updates ===

Contributors: coffeecode
Requires at least: 5.0
Requires PHP: 7.1
Tested up to: 6.4.1
Stable tag: 3.2.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Changelog ==

= 3.2.0 - 24/01/2024 =
- Atualizando configurações do plugin.

= 3.1.0 - 12/01/2024 =
- Atualizando versão da api.

= 3.0.0 - 27/11/2023 =
- Atualizando a versão.

= 1.2.8 - 21/07/2023 =
- Alterando função para deletar pasta temporária.

= 1.2.7 - 19/04/2023 =
- Alterando função para download de temas e plugins.

= 1.2.6 - 23/01/2023 =
- Adicionando ajax para atualizar token.
- Adicionando data de expiração do token.

= 1.2.5 - 05/09/2022 =
- Adicionando pasta temporaria na pasta de uploads.

= 1.2.4 - 30/08/2022 =
- Removendo transiente da busca na api.

= 1.2.3 - 18/08/2022 =
- Resolvendo problema de busca do email do cliente.

= 1.2.0 - 20/07/2022 =
- Atualizando plugin.

= 1.1.0 - 06/02/2021 =
- Alterando o campo de token para password.

= 1.0.0 - 10/11/2020 =
- Release inicial
